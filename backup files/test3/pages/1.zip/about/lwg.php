<div class="content">
                        <!--  section --> 
                        <section class="parallax-section header-section" data-scrollax-parent="true" id="sec1">
                            <div class="bg"  data-bg="assets/images/bg/gpdi.png" data-scrollax="properties: { translateY: '200px' }"></div>
                            <div class="overlay"></div>
                            <div class="container big-container">
                                <div class="section-title">
                                    <h3>GPdI Bukit Hermon</h3>
                                    <div class="separator trsp-separator"></div>
                                    <h2>LWG SCHOOL</h2>
                                    <!-- <p>Curabitur bibendum mi sed rhoncus aliquet. Nulla blandit porttitor justo, at posuere sem accumsan nec.</p> -->
                                    <a href="#sec2" class="custom-scroll-link sect-scroll-link"><i class="fa fa-long-arrow-down"></i> <span>scroll down</span></a>
                                </div>
                            </div>
                        </section>
                        <!--  section end--> 
                        <!--  section  --> 
                        <section id="sec2" data-scrollax-parent="true" >
                            <div class="container">
                                <div class="section-container fl-wrap">
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="content-wrap about-wrap">
											<h3 class="bold-title">Sekolah Paud TK LWG (Love Will Grow)</h3>
											<br>
											<h3 class="bold-title">Vision</h3>
											<p>Educating a new generation of leaders who <b style='font-size:25px;'>LOVE</b> God wholeheartedly; <b style='font-size:25px;'>WILL</b> to serve people in humility and <b style='font-size:25px;'>GROW</b> academically in a Christ-centered environment</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
							
							<div class="container">
                                <div class="section-container fl-wrap">
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="content-wrap about-wrap">
                                            <h3 class="bold-title">Mission</h3>
												<p>• &nbsp;&nbsp; <b style='font-size:25px;'>Learning with God</b> - Educating spiritual truths to a new generation to love God wholeheartedly.</p>
												<p>• &nbsp;&nbsp; <b style='font-size:25px;'>Learning with Grace</b> -  Cultivating character development in leaders who will to serve in humility.</p>
												<p>• &nbsp;&nbsp; <b style='font-size:25px;'>Learning with Giggles</b> - Equipping academic skills for leaders to grow in a Christ Centered environment</p>
                                            </div>
                                        </div>
                                    </div>
								</div>
                            </div>
							
							<div class="container">
                                <div class="section-container fl-wrap">
									<div class="row">
                                        <div class="col-md-12">
                                            <div class="content-wrap about-wrap">
                                            <p>Untuk Info Lebih Lanjut <a href='http://thecouturecrown.com/amberjolianam-building-a-school/' style='font-size:25px;'> <b>Klik Disini</b>.</a><br><br>
                                            <iframe style='width:100%;' height=690 src="https://www.youtube.com/embed/1g8Ha9wq830"></iframe></p>
                                            </div>
                                        </div>
                                    </div>
								</div>
                            </div>
							
                            
                            <!-- <div class="bg dec-bg left-pos-dec"  data-bg="assets/images/bg/14.jpg"></div> -->
                        </section>
                        <!--  section end--> 
                        
                            <div class="partcile-dec"></div>
                            <div class="border-section-wrap">
                                <div class="border-section"></div>
                            </div>
                        <!--  section end--> 
                        <div class="limit-box fl-wrap"></div>
                    </div>