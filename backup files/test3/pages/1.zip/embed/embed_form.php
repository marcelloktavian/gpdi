<form action="embed_save.php" method="post">
    <table>
        <tr>
            <td><label>Ibadah Online</label></td>
            <td><input type="text" name="online" id="online"></td>
        </tr>
        <tr>
            <td><label>Ibadah Anak</label></td>
            <td><input type="text" name="anak" id="anak"></td>
        </tr>
        <tr>
            <td></td>
            <td><button type="submit" style="width:100%">Save</button></td>
        </tr>
</form>