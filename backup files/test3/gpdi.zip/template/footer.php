<div class="height-emulator"></div>
<footer class="content-footer">
                        <div class="footer-inner">
                            <div class="row">
                                <div class="col-md-3">
                                    <a class="footer-logo" href="index.php"><img src="assets/images/logo.png" alt=""></a>
                                </div>
                                <div class="col-md-6">
                                    <!-- <div class="footer-header fl-wrap"><span>01.</span> Contacts</div> -->
                                    <div class="fl-wrap footer-box">
                                        <ul>
                                            <li><span>Mail : </span><a href="mailto:admin@gpdibukithermon.org" target="_blank">admin@gpdibukithermon.org</a></li>
                                            <li> <span>Address : </span><a href="https://www.google.com/maps/place/GPdI+Bukit+Hermon/@-6.8993,107.5495295,17z/data=!4m5!3m4!1s0x2e68e5a5002cccdf:0x8d2b53576e55899c!8m2!3d-6.8993053!4d107.5517182" target="_blank">Jl. Mahar Martanegara No.103, Kel.Cigugur Tengah, Kec. Cimahi Tengah, Kota Cimahi,Jawa Barat 40522</a></li>
                                            <li><span>Phone : </span>+62(22)20560199</li>
                                            <li><span>Whatsapp : </span><a href="https://api.whatsapp.com/send?phone=6281212000103">+6281212000103</a></li>
                                            
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3"></div>
                                <div class="col-md-9">
                                    <div class="fl-wrap policy-box">
                                        <p> &#169; GPdI Bukit Hermon   2022.  All rights reserved.  </p>
                                    </div>
                                </div>
                            </div>
                            <!-- <div class="to-top"><i class="fa fa-long-arrow-up"></i></div> -->
                        </div>
                    </footer>