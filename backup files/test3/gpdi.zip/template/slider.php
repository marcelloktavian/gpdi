<footer class="main-footer">
                <div class="fixed-title"><span>GPdI Bukit Hermon</span></div>
                <div class="footer-social">
                    <ul >
                        <li><a href="https://www.facebook.com/checkpoint/828281030927956/?next=https%3A%2F%2Fwww.facebook.com%2Fgpdi.bukithermon%2F" target="_blank" ><i class="fa fa-facebook"></i></a></li>
                        <!-- <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li> -->
                        <li><a href="https://www.instagram.com/gpdibukithermon.cmh" target="_blank" ><i class="fa fa-instagram"></i></a></li>
                        <li><a href="https://www.youtube.com/channel/UCQ-7t0hUy9Ln_nbqmrH1qKQ" target="_blank" ><i class="fa fa-youtube"></i></a></li>
                        <!-- <li><a href="#" target="_blank" ><i class="fa fa-tumblr"></i></a></li> -->
                    </ul>
                </div>
            </footer>