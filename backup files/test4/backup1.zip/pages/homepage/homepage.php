<style>
    #content-services {
        color: #ffffff;
        transition: color 3s ease 0s;
        height: 180px;
    }
</style>
<!-- home-slider  -->
<div class="fs-gallery-wrap home-slider fl-wrap full-height" data-autoplayslider="5000">
                        <div class="slide-progress-container">
                            <div class="slide-progress-content">
                                <div class="slide-progress-warp">
                                    <div class="slide-progress"></div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-container" data-scrollax-parent="true" >
                            <div class="swiper-wrapper"  >
                                <!-- swiper-slide-->
                                <div class="swiper-slide">
                                    <div class="bg"  data-bg="assets/images/bg/welcomehome.png" data-scrollax="properties: { translateY: '250px' }" ></div>
                                    <a href="assets/images/bg/welcomehome.png" class="  gallery-popup image-popup"><i class="fa fa-search" ></i></a>
                                    <div class="overlay"></div>
                                    <!-- hero-wrap-->           
                                    <div class="hero-wrap alt">
                                        <div class="container">
                                            <!-- <div class="hero-item"> -->
                                            	<!-- <h3>GPDI Bukit Hermon</h3>
                                                <h2>WELCOME HOME</h2> -->
                                                <!-- <div class="clearfix"></div> -->
                                                <!-- <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary .</p> -->
                                                <!-- <div class="clearfix"></div> -->
                                                <!-- <a href="portfolio.html" class="btn float-btn flat-btn">Our portfolio</a> -->
                                            <!-- </div> -->
                                        </div>
                                    </div>
                                    <!-- hero-wrap end-->   
                                </div>
                                <!-- swiper-slide end-->
                                <!-- swiper-slide-->
                                <div class="swiper-slide">
                                    <div class="bg"  data-bg="assets/images/bg/doajumat.png" data-scrollax="properties: { translateY: '250px' }" ></div>
                                    <a href="assets/images/bg/doajumat.png" class="gallery-popup image-popup"><i class="fa fa-search"  ></i></a>
                                    <div class="overlay"></div>
                                    <!-- hero-wrap-->           
                                    <div class="hero-wrap alt">
                                        <div class="container">
                                            <!-- <div class="hero-item"> -->
                                            	<!-- <h3>GPDI Bukit Hermon</h3>
                                                <h2> DOA JUMAT</h2> -->
                                                <!-- <div class="clearfix"></div> -->
                                                <!-- <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary .</p> -->
                                                <!-- <div class="clearfix"></div> -->
                                                <!-- <a href="portfolio-single.html" class="btn float-btn flat-btn">View Project</a> -->
                                            <!-- </div> -->
                                        </div>
                                    </div>
                                    <!-- hero-wrap end-->   
                                </div>
                                <!-- swiper-slide end-->
                                <!-- swiper-slide-->
                                <!-- <div class="swiper-slide">
                                    <div class="bg"  data-bg="assets/images/bg/3a.jpg" data-scrollax="properties: { translateY: '250px' }" ></div>
                                    <a href="assets/images/bg/3a.jpg" class="  gallery-popup image-popup"><i class="fa fa-search"  ></i></a>
                                    <div class="overlay"></div> -->
                                    <!-- hero-wrap-->           
                                    <!-- <div class="hero-wrap alt">
                                        <div class="container">
                                            <div class="hero-item">
                                            	<h3>tend to repeat</h3>                                            
                                                <h2> Gbr3a <br> Project Title</h2>
                                                <div class="clearfix"></div>
                                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary .</p>
                                                <div class="clearfix"></div>
                                                <a href="portfolio-single.html" class="btn float-btn flat-btn">View Project</a>
                                            </div>
                                        </div>
                                    </div> -->
                                    <!-- hero-wrap end-->   
                                <!-- </div> -->
                                <!-- swiper-slide end-->
                                <!-- swiper-slide-->
                                <!-- <div class="swiper-slide">
                                    <div class="bg"  data-bg="assets/images/bg/4a.jpg" data-scrollax="properties: { translateY: '250px' }" ></div>
                                    <a href="assets/images/bg/4a.jpg" class="gallery-popup image-popup"><i class="fa fa-search"  ></i></a>
                                    <div class="overlay"></div> -->
                                    <!-- hero-wrap-->           
                                    <!-- <div class="hero-wrap alt">
                                        <div class="container">
                                            <div class="hero-item">
                                            	<h3>Cras lacinia magna</h3>                                              
                                                <h2> Gbr4a <br> What we do</h2>
                                                <div class="clearfix"></div>
                                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary .</p>
                                                <div class="clearfix"></div>
                                                <a href="services.html" class="btn float-btn flat-btn">Our Services</a>
                                            </div>
                                        </div>
                                    </div> -->
                                    <!-- hero-wrap end-->   
                                <!-- </div> -->
                                <!-- swiper-slide end-->
								<!-- <div class="swiper-slide">
                                    <div class="bg"  data-bg="assets/images/bg/Cover_Januari.jpg" data-scrollax="properties: { translateY: '250px' }" ></div>
                                    <a href="assets/images/bg/4a.jpg" class="gallery-popup image-popup"><i class="fa fa-search"  ></i></a>
                                    <div class="overlay"></div> -->
                                    <!-- hero-wrap-->           
                                    <!-- <div class="hero-wrap alt">
                                        <div class="container">
                                            <div class="hero-item">
                                            	<h3>Cras lacinia magna</h3>                                              
                                                <h2> Cover Januari <br> What we do</h2>
                                                <div class="clearfix"></div>
                                                <p>All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary .</p>
                                                <div class="clearfix"></div>
                                                <a href="services.html" class="btn float-btn flat-btn">Our Services</a>
                                            </div>
                                        </div>
                                    </div> -->
                                    <!-- hero-wrap end-->   
                                <!-- </div> -->
                                <!-- swiper-slide end-->
                            </div>
                            <div class="sw-button swiper-button-next"><i class="fa fa-angle-right"></i></div>
                            <div class="sw-button swiper-button-prev"><i class="fa fa-angle-left"></i></div>
                            <div class="swiper-pagination"></div>
                        </div>
                    </div>
                    <!-- home-slider end-->
                    <!--content-->	 
                    <div class="content">
                        <!--section -->	
                        <section id="sec2" data-scrollax-parent="true" >
                            <div class="container">
                                <div class="section-container fl-wrap">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="content-wrap about-wrap">
                                                <h3 class="bold-title">Welcome to GPdI Bukit Hermon  </h3>
                                                
												<p><span style='font-size: 22px;font-style: normal; line-height: 1.5;'>Selamat datang di situs resmi kami, Gereja Pantekosta di Indonesia (GPdI) Bukit Hermon, Cimahi.
Website ini dibangun sebagai sarana informasi dan komunikasi bagi jemaat. Untuk keterangan lebih lanjut silakan hubungi sekretariat gereja, Tuhan Yesus memberkati. </span></p>
													
                                                <br><br>
                                                <h3 class="bold-title">Services</h3>
                                                <div class="pr-tags fl-wrap">
                                                    <ul>
                                                        <li style='padding-top:5px;padding-bottom:5px;'><a href="javascript:void(0)" id="ibra1" style='font-size: 20px;font-style: normal;'>Ibadah 1</a></li>
                                                        <li style='padding-top:5px;padding-bottom:5px;'><a href="javascript:void(0)" id="ibra2" style='font-size: 20px;font-style: normal;'>Ibadah 2</a></li>
                                                        <li style='padding-top:5px;padding-bottom:5px;'><a href="javascript:void(0)" id="ibraanak" style='font-size: 20px;font-style: normal;'>Ibadah Anak</a></li>
                                                        <li style='padding-top:5px;padding-bottom:5px;'><a href="javascript:void(0)" id="ibraonline" style='font-size: 20px;font-style: normal;'>Ibadah Online</a></li>
                                                        <li style='padding-top:5px;padding-bottom:5px;'><a href="javascript:void(0)" id="doajumat" style='font-size: 20px;font-style: normal;'>Doa Jumat</a></li>
                                                    </ul>
                                                </div>

                                                <div class="clearfix"></div>
                                                <br><br><br>
                                                <div class="content-wrap about-wrap">
                                                    <div id="content-services"></div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="bg dec-bg left-pos-dec"  data-bg="assets/images/bg/14.jpg"></div>
                        </section>
                        <!--section end  -->	
                        <!--section -->	
                        <!-- <section  >
                            <div class="bg"  data-bg="assets/images/bg/1.jpg"></div>
                            <div class="overlay"></div>
                            <div class="container">
                                <div class="intro-text fl-wrap">
                                    <h2>Entrust your project <br>to our team of  <br>professionals</h2>
                                    <a href="services.html" class="btn float-btn flat-btn">Our Services</a>
                                    <a href="contact.html" class="btn float-btn flat-btn">Get in Touch</a>
                                </div>
                            </div>
                        </section> -->
                        <!--section end  -->	
                        <!--section -->	                             	 
                        <!-- <section >
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-12">
										
                                    </div>
                                </div> -->
                                <!--parallax-item end-->	                       
                            <!-- </div> -->
                            <!-- <div class="partcile-dec" data-parcount="250"></div> -->
                        <!-- </section> -->
                        <!--section end  -->	
                        <!--section -->	
                        <!-- <section class="parallax-section header-section  " data-scrollax-parent="true" id="sec6">
                            <div class="bg"  data-bg="assets/images/bg/1.jpg" data-scrollax="properties: { translateY: '200px' }"></div>
                            <div class="overlay"></div>
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="pr-title">
                                            Testimonials
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="single-slider testilider fl-wrap" data-effects="slide">
                                            <div class="swiper-container">
                                                <div class="swiper-wrapper"> -->
                                                    <!-- swiper-slide -->
                                                    <!-- <div class="swiper-slide">
                                                        <div class="testi-item fl-wrap">
                                                            <h3>Andy Smith</h3>
                                                            <p>"All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words"</p>
                                                            <a href="#" class="btn float-btn flat-btn" target="_blank">Via Twitter</a>
                                                        </div>
                                                    </div> -->
                                                    <!-- swiper-slide end-->
                                                    <!-- swiper-slide -->
                                                    <!-- <div class="swiper-slide">
                                                        <div class="testi-item fl-wrap">
                                                            <h3>Liza Mirovsky</h3>
                                                            <p>"Vestibulum orci felis, ullamcorper non condimentum non, ultrices ac nunc. Mauris non ligula suscipit, vulputate mi accumsan, dapibus felis. Nullam sed sapien dui. Nulla auctor sit amet sem non porta. Integer iaculis tellus nulla, quis imperdiet magna venenatis vitae"</p>
                                                            <a href="#" class="btn float-btn flat-btn" target="_blank">Via Facebook</a>
                                                        </div>
                                                    </div> -->
                                                    <!-- swiper-slide end-->
                                                    <!-- swiper-slide -->
                                                    <!-- <div class="swiper-slide">
                                                        <div class="testi-item fl-wrap">
                                                            <h3>Gary Trust</h3>
                                                            <p>"If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text."</p>
                                                            <a href="#" class="btn float-btn flat-btn" target="_blank">Via Myspace</a>
                                                        </div>
                                                    </div> -->
                                                    <!-- swiper-slide end-->
                                                <!-- </div>
                                                <div class="swiper-pagination"></div>
                                                <div class="swiper-button-prev"><i class="fa fa-angle-left"></i></div>
                                                <div class="swiper-button-next"><i class="fa fa-angle-right"></i></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section> -->
                        <!--section end  -->	
                        <!--section -->	
                        <!-- <section>
                            <div class="container">
                                <div class="clients-list fl-wrap">
                                    <ul>
                                        <li><a href="#" target="_blank"> <img src="assets/images/clients/1.jpg" alt=""> </a></li>
                                        <li><a href="#" target="_blank"> <img src="assets/images/clients/1.jpg" alt=""> </a></li>
                                        <li><a href="#" target="_blank"> <img src="assets/images/clients/1.jpg" alt=""> </a></li>
                                        <li><a href="#" target="_blank"> <img src="assets/images/clients/1.jpg" alt=""> </a></li>
                                        <li><a href="#" target="_blank"> <img src="assets/images/clients/1.jpg" alt=""> </a></li>
                                    </ul>
                                </div>
                            </div>
                        </section> -->
                        <!--section end  -->	
                        <!--social-wrap -->	  
                        <!-- <div class="social-wrap fl-wrap">
                            <ul>
                                <li><a href="#" target="_blank" ><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#" target="_blank" ><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#" target="_blank" ><i class="fa fa-pinterest"></i></a></li>
                                <li><a href="#" target="_blank" ><i class="fa fa-tumblr"></i></a></li>
                            </ul>
                        </div> -->
                        <!--social-wrap end-->	
                    </div>

<script>
    $( "#ibra1" ).click(function() {
        var html = '';
        html += '<p style="text-align:center;"><span style="font-size:20px;">Mari bergabung dalam <b>Ibadah Raya 1</b> kami di gedung gereja maupun siaran langsung <b>media sosial</b> kami.</span><br><br>';
        html += '<b style="font-size:20px;">Setiap Hari Minggu<br>';
        html += '07.00</b><br><br>';
        html += '<i>Ibadah dimulai 15 menit sebelum waktunya<br>';
        html += 'Tetap patuhi protokol kesehatan dengan menggunakan masker dan tetap menjaga jarak ketika mengikuti ibadah di gedung gereja.</i></p>';

        $("#content-services").html(html);
        document.getElementById("content-services").style.color = "#333333";
    });

    $( "#ibra2" ).click(function() {
        var html = '';
        html += '<p style="text-align:center;"><span style="font-size:20px;">Mari bergabung dalam <b>Ibadah Raya 2</b> kami di gedung gereja maupun siaran langsung <b>media sosial</b> kami.</span><br><br>';
        html += '<b style="font-size:20px;">Setiap Hari Minggu<br>';
        html += '10.00</b><br><br>';
        html += '<i>Ibadah dimulai 15 menit sebelum waktunya<br>';
        html += 'Tetap patuhi protokol kesehatan dengan menggunakan masker dan tetap menjaga jarak ketika mengikuti ibadah di gedung gereja.</i></p>';

        $("#content-services").html(html);
        document.getElementById("content-services").style.color = "#333333";
    });

    $( "#ibraanak" ).click(function() {
        var html = '';
        html += '<p style="text-align:center;"><span style="font-size:20px;">Mari bergabung dalam <b>Ibadah Anak</b> kami di gedung gereja maupun siaran langsung <b>media sosial</b> kami.</span><br><br>';
        html += '<b style="font-size:20px;">Setiap Hari Minggu<br>';
        html += '08.00</b><br><br>';
        html += '<i>Ibadah dimulai 15 menit sebelum waktunya<br>';
        html += 'Tetap patuhi protokol kesehatan dengan menggunakan masker dan tetap menjaga jarak ketika mengikuti ibadah di gedung gereja.</i></p>';

        $("#content-services").html(html);
        document.getElementById("content-services").style.color = "#333333";
    });

    $( "#ibraonline" ).click(function() {
        var html = '';
        html += '<p style="text-align:center;"><span style="font-size:20px;">Mari bergabung dalam <b>Ibadah Online</b> di siaran langsung <b>media sosial</b> kami. Silakan kunjungi <b> <a href="https://www.youtube.com/channel/UCQ-7t0hUy9Ln_nbqmrH1qKQ" target="_blank">channel youtube</a></b> kami.</span><br><br>';
        html += '<b style="font-size:20px;">Setiap Hari Minggu<br>';
        html += '10.30</b></p>';


        $("#content-services").html(html);
        document.getElementById("content-services").style.color = "#333333";
    });

    $( "#doajumat" ).click(function() {
        var html = '';
        html += '<p style="text-align:center;"><span style="font-size:20px;">Mari bergabung dalam <b>Doa Jumat</b> kami di gedung gereja.</span><br><br>';
        html += '<b style="font-size:20px;">Setiap Hari Jumat<br>';
        html += '18.00</b><br><br>';
        html += '<i>Ibadah dimulai 15 menit sebelum waktunya<br>';
        html += 'Tetap patuhi protokol kesehatan dengan menggunakan masker dan tetap menjaga jarak ketika mengikuti ibadah di gedung gereja.</i></p>';

        $("#content-services").html(html);
        document.getElementById("content-services").style.color = "#333333";
    });
</script>