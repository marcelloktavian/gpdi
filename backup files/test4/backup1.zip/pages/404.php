<div class="content full-height">
                        <div class="error-wrap">
                            <div class="container">
                                <h2>404</h2>
                                <p> The Page you were looking for, couldn't be found.</p>
                                <a href="index.php" class="btn float-btn flat-btn">Back to home</a>     
                            </div>
                        </div>
                        <div class="partcile-dec" data-parcount="200"></div>
                    </div>